from sect08_module.fibo import fib as f1, fib2 as f2

f1(500)

result = f2(600)
print(result)
