import sect08_module.fibo

fibo = sect08_module.fibo
fibo.fib(100)

fib = fibo.fib
fib(200)






