from sect08_module.fibo import *

fib(300)

result = fib2(400)
print(result)




