# No Return Function
def sayHello():
    print('Hi, Guys !!')

sayHello()
# print(sayHello())
